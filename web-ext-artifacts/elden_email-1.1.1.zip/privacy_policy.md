# Elden Email Privacy Policy

Elden Email does not collect, transmit, or share any personally identifiable information, financial data, authentication information, communication contents, location data, or browsing history.

The extension stores only user preferences (banner color and sound setting) locally on the user's browser using Chrome's storage API. These preferences are not shared with any third party and are never transmitted over the internet.

Elden Email does not access, read, or store any email contents.  
No data collected by the extension is used for analytics, advertising, or any purpose beyond the extension's single function.

If you have questions, contact: anna.mettifogo@gmail.com